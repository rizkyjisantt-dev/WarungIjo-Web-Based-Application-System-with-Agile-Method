<?php 
$page_id = null;
$comp_model = new SharedController;
$current_page = $this->set_current_page_link();
?>
<div>
    <div  class="bg-light p-3 mb-3">
        <div class="container">
            <div class="row ">
                <div class="col-md-12 comp-grid">
                    <h4 >The Dashboard</h4>
                </div>
                <div class="col-md-6 comp-grid">
                    <div class="text-left">
                        <h4></h4>
                        <p class="text-muted"></p>
                    </div>
                    <div class="smartwizard" data-theme="dots" data-form-action="">
                        <ul>
                            <li>
                                <a href="#FormWizard-1-Page1">
                                    Step 1
                                    <br /><small></small>
                                </a>
                            </li>
                            <li>
                                <a href="#FormWizard-1-Page2">
                                    Step 2
                                    <br /><small></small>
                                </a>
                            </li>
                            <li>
                                <a href="#FormWizard-1-Page3">
                                    Step 3
                                    <br /><small></small>
                                </a>
                            </li>
                            <li>
                                <a href="#FormWizard-1-Page4">
                                    Step 4
                                    <br /><small></small>
                                </a>
                            </li>
                            <li>
                                <a href="#FormWizard-1-Page5">
                                    Step 5
                                    <br /><small></small>
                                </a>
                            </li>
                        </ul>
                        <div>
                            <div class="card formtab" id="FormWizard-1-Page1" data-next-page="FormWizard-1-Page2" data-submit-action="MOVE-NEXT">
                                <div class="">
                                    <div class="text-center">
                                        <div class="p-3">
                                            <h4>Welcome To Form Wizard</h4>
                                            <hr />
                                            <p class="text-muted">You can drag and drop <b>Add Sub Page</b> onto the form wizard steps</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-center p-3">
                                    <button class="btn btn-success sw-btn-next">Getting Started</button>
                                </div>
                            </div>
                            <div class="card formtab" id="FormWizard-1-Page2" data-next-page="FormWizard-1-Page3" data-submit-action="SUBMIT-STEP-FORM">
                                <div class=" p-3">
                                </div>
                            </div>
                            <div class="card formtab" id="FormWizard-1-Page3" data-next-page="FormWizard-1-Page4" data-submit-action="SUBMIT-STEP-FORM">
                                <div class=" p-3">
                                </div>
                            </div>
                            <div class="card formtab" id="FormWizard-1-Page4" data-next-page="FormWizard-1-Page5" data-submit-action="SUBMIT-ALL-FORMS">
                                <div class=" p-3">
                                </div>
                            </div>
                            <div class="card formtab" id="FormWizard-1-Page5" data-next-page="FormWizard-1-Page6" data-submit-action="">
                                <div class="">
                                    <div class="text-center">
                                        <h4>Form Wizard Completed</h4>
                                        <hr />
                                        <p class="text-muted">Thank you for your support</p>
                                    </div>
                                </div>
                                <div class=" p-3">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 comp-grid">
                </div>
                <div class="col-md-6 comp-grid">
                    <div id="Comp-1-Accordion-Group" role="tablist" class="accordion-group">
                        <div class="card">
                            <div class="card-header accordion-header" data-toggle="collapse" data-target="#Accordion-1-Page1" role="tab">
                                Title 1 <span class="expand text-muted">+</span>
                            </div>
                            <div id="Accordion-1-Page1" class="collapse show" data-parent="#Comp-1-Accordion-Group">
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header accordion-header" data-toggle="collapse" data-target="#Accordion-1-Page2" role="tab">
                                Title 2 <span class="expand text-muted">+</span>
                            </div>
                            <div id="Accordion-1-Page2" class="collapse show" data-parent="#Comp-1-Accordion-Group">
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header accordion-header" data-toggle="collapse" data-target="#Accordion-1-Page3" role="tab">
                                Title 3 <span class="expand text-muted">+</span>
                            </div>
                            <div id="Accordion-1-Page3" class="collapse show" data-parent="#Comp-1-Accordion-Group">
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header accordion-header" data-toggle="collapse" data-target="#Accordion-1-Page4" role="tab">
                                Title 4 <span class="expand text-muted">+</span>
                            </div>
                            <div id="Accordion-1-Page4" class="collapse show" data-parent="#Comp-1-Accordion-Group">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 comp-grid">
                </div>
            </div>
        </div>
    </div>
</div>
