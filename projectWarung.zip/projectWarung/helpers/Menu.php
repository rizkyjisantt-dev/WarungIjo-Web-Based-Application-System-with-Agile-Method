<?php
/**
 * Menu Items
 * All Project Menu
 * @category  Menu List
 */

class Menu{
	
	
			public static $navbarsideleft = array(
		array(
			'path' => 'home', 
			'label' => 'Home', 
			'icon' => '<i class="material-icons ">home</i>'
		),
		
		array(
			'path' => 'list_menu', 
			'label' => 'List Menu', 
			'icon' => '<i class="material-icons ">local_dining</i>'
		),
		
		array(
			'path' => 'pemesanan', 
			'label' => 'Pemesanan', 
			'icon' => '<i class="material-icons ">shopping_cart</i>'
		),
		
		array(
			'path' => 'pembayaran', 
			'label' => 'Pembayaran', 
			'icon' => ''
		),
		
		array(
			'path' => 'penyajian', 
			'label' => 'Penyajian', 
			'icon' => ''
		),
		
		array(
			'path' => 'pelanggan', 
			'label' => 'Pelanggan', 
			'icon' => ''
		),
		
		array(
			'path' => 'pelayan', 
			'label' => 'Pelayan', 
			'icon' => ''
		),
		
		array(
			'path' => 'user', 
			'label' => 'User', 
			'icon' => ''
		),
		
		array(
			'path' => 'role_permissions', 
			'label' => 'Role Permissions', 
			'icon' => ''
		),
		
		array(
			'path' => 'roles', 
			'label' => 'Roles', 
			'icon' => ''
		)
	);
		
	
	
}